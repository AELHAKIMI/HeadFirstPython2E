from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.0',
    description='The Head First Python Search Tools',
    author = 'Ayoub EL HAKIMI',
    author_email = 'Ay.elhakimi@gmail.com',
    url ='Ayoubelhakimi@gmail.com',
    py_modules=['vsearch'],
)